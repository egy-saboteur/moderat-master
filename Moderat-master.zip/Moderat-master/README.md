# ModeRat

(UNDER DEVELOPMENT)
Experimental Remote Administration & Spy Tool

###### Supports
Server and Viewer:  Windows 7,8,10 (x86/x64), Kali linux 2 (x64)

Client (Build with PyInstaller 3.2): Windows 7, 9, 10 (x86/x64)

Server Features
 * Clients / Moderators Managment System With Database
 * Clients Recorded Audios, Desktop Screenshots, Keylogs Database
 * The Server Generates a Source and Sends To The Client For Execution
 * Client Source Can Be Changed Dynamically

Viewer Features:
 * User Friendly Gui
 * Multi Language Support
 * Online/Offline Clients & Moderators Management System
 * Online/Offline Clients & Moderators Information Live Update
 * Identify Ip Address Country
 * Alias System
 * LOG VIEWER: Download and View Clients Recorded Audios, Desktop Screenshots, Keylogs From Server
 * Screenshots and Keylogs Preview
 * Audio Spectrum Analyzer

Modules:
 *  Interactive Remote Shell
 *  Remote File Management With Basic Commands
 *  Remote Desktop Screen Capture and Save
 *  Remote Webcam Capture and Save
 *  Execute Python Scripts Remotely (Plugins System)



###### Screenshots

* Server
![Moderat Connections](http://s020.radikal.ru/i700/1609/c4/2189023024d3.png)
* Viewer
![Moderat Connections](http://s13.radikal.ru/i186/1609/ab/a6d1e4c9c135.png)
* Log Viewer
![Moderat Connections](http://s017.radikal.ru/i440/1609/bd/2252b31bf9bc.png)
* Modules
![Moderat Connections](http://s020.radikal.ru/i716/1609/2f/6ac08ed5a75f.png)
